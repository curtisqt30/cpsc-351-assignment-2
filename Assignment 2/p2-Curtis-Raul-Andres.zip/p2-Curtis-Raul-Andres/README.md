# Process Synchronization
Fall 2024 CPSC 351-02 18007

Assignment 02

## Student Info
* Curtis Quan-Tran - cquantran@csu.fullerton.edu - Section 02
* Raul Zabala - rczabala@csu.fullerton.edu - Section 02
* Andres Loera - Andresloera45@csu.fullerton.edu@csu.fullerton.edu - Section 02

## How to Run
* Language: C
* Platform: Linux
  1. Open terminal
  2. Change directory to location of TA.c
  3. Compile TA.c using gcc -o "choose file name" TA.c
  4. Run the executable file in the terminal using ./ "file name" <number of students>

## Collaboration Notes
* Curtis Quan-Tran: TA_Activity Function
* Raul Zabala: Main and Documentation
* Andres Loera: Student_Acitivity Function
